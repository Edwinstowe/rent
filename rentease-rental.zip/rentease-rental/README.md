# RentEase: Rental Property Management System

## Files
- `index.html`  page structure (open this file in a browser)
- `style.css`   all styling (colours are CSS variables at the top of the file)
- `script.js`   all logic: data, login and registration, role screens, notifications


## Run
Double-click `index.html`. To test location or other browser features, run `python -m http.server 8000` in this folder and open http://localhost:8000

## Edit in VS Code
Open the folder (File > Open Folder). Install the Live Server extension and choose "Go Live" to refresh the page on every save.

## Notes
- The first account you register becomes the Administrator.
- Data is saved in the browser (localStorage). To reset it, open the browser developer tools, go to Application > Local Storage and clear the site data.
- In `script.js`, the line starting `const KEY=` sets the storage name, and `function seed()` holds the sample data.
