const $=id=>document.getElementById(id);
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const DAY=864e5,now=Date.now(),iso=d=>new Date(d).toISOString().slice(0,10),today=iso(now);
const ago=t=>{const h=Math.round((Date.now()-t)/36e5);return h<1?'just now':h<48?h+'h ago':Math.round(h/24)+'d ago'};
const money=n=>'KES '+Number(n).toLocaleString('en-US');
const tag=(t,c)=>`<span class="tag ${c||String(t).replace(/\W/g,'')}">${esc(t)}</span>`;
const card=h=>`<div class="card">${h}</div>`;
const btn=(t,f,c)=>`<button class="btn sm ${c||''}" onclick="${f}">${t}</button>`;
const empty=t=>`<div class="empty">${t}</div>`;
const stat=(n,l,c)=>`<div class="card stat"><b class="${c||''}">${n}</b>${l}</div>`;
const bars=rows=>{const mx=Math.max(1,...rows.map(r=>r[1]));return rows.map(([l,v])=>`<div class="bar"><span>${esc(l)}</span><i style="width:${Math.max(3,v/mx*60)}%"></i><b>${v}</b></div>`).join('')};
const toast=m=>{const t=$('toast');t.textContent=m;t.style.display='block';clearTimeout(toast.h);toast.h=setTimeout(()=>t.style.display='none',2800)};

const UNITS=[{id:'A1',prop:'Kileleshwa Heights',rent:18000,start:'2026-06'},{id:'A2',prop:'Kileleshwa Heights',rent:18000,start:'2026-08'},{id:'B1',prop:'Riverside Court',rent:25000,start:'2026-05'},{id:'B2',prop:'Riverside Court',rent:25000,start:'2026-09'},{id:'C1',prop:'Garden Flats',rent:12000,start:'2026-07'}];
const label=u=>`${u.id} — ${u.prop} (${money(u.rent)})`;
const KEY='rn',ROLES=['Tenant','Caretaker'],PROFROLE='Tenant',PROFLABEL='Your unit',PROF=UNITS.map(label);
function seed(){return{pays:[
{id:1,unit:'A1',amt:18000,code:'SJK2A8B3QX',status:'Confirmed',at:now-90*DAY},{id:2,unit:'A1',amt:18000,code:'SKM7C1D9LP',status:'Confirmed',at:now-60*DAY},{id:3,unit:'A1',amt:18000,code:'SLN3F5G2RT',status:'Confirmed',at:now-30*DAY},
{id:4,unit:'B1',amt:25000,code:'SIH8Q2W4ZE',status:'Confirmed',at:now-120*DAY},{id:5,unit:'B1',amt:50000,code:'SJT5V6B1NM',status:'Confirmed',at:now-75*DAY},{id:6,unit:'B1',amt:25000,code:'SLP9X3C7KD',status:'Confirmed',at:now-20*DAY},
{id:7,unit:'B2',amt:25000,code:'SMQ4R8T2YU',status:'Pending',at:now-2*DAY}],
fix:[{id:1,unit:'A1',by:'Tenant',title:'Leaking kitchen tap',desc:'Water drips all day.',urg:'Normal',status:'Open',at:now-3*DAY,log:['Reported']}],
notices:[{id:1,text:'Water will be off on Saturday from 8am to 12pm for tank cleaning.',at:now-2*DAY}],notes:[],seq:8,fseq:2,nseq:2}}
const tabs=()=>role==='Tenant'?[['home','My unit'],['fix','Repairs'],['notices','Notices'],['alerts','Alerts']]:role==='Caretaker'?[['home','Repairs'],['notices','Notices'],['alerts','Alerts']]:[['home','Overview'],['units','Units'],['pays','Payments'],['fix','Repairs'],['notices','Notices'],['alerts','Alerts']];
const unitOf=p=>UNITS.find(u=>p&&p.startsWith(u.id+' '));
const mdue=u=>{const[y,m]=u.start.split('-').map(Number),d=new Date();return Math.max(0,d.getFullYear()*12+d.getMonth()+1-(y*12+m)+1)};
const paid=u=>S.pays.filter(p=>p.unit===u.id&&p.status==='Confirmed').reduce((a,p)=>a+p.amt,0);
const bal=u=>mdue(u)*u.rent-paid(u);
const tenantOf=u=>(getU().find(x=>x.role==='Tenant'&&unitOf(x.prof)&&unitOf(x.prof).id===u.id)||{}).name||'Vacant';
const payCard=p=>card(`<div class="row"><b>${money(p.amt)}</b>${tag(p.status)}</div><div class="sub">Unit ${p.unit} · M-Pesa ${esc(p.code)} · ${ago(p.at)}</div>`);
function submitPay(){const u=unitOf(prof),amt=+$('pa').value,code=$('pc').value.trim().toUpperCase();
 if(!(amt>0))return toast('Enter the amount paid');
 if(!/^[A-Z0-9]{10}$/.test(code))return toast('The M-Pesa code has 10 letters and numbers');
 if(S.pays.some(p=>p.code===code))return toast('That M-Pesa code was already recorded');
 S.pays.unshift({id:S.seq++,unit:u.id,amt,code,status:'Pending',at:Date.now()});notify(`Payment of ${money(amt)} for ${u.id} awaits confirmation (${code}).`,'Admin');save();toast('Payment recorded for confirmation');draw()}
function confirmPay(id,ok){const p=S.pays.find(x=>x.id===id),u=UNITS.find(x=>x.id===p.unit);p.status=ok?'Confirmed':'Rejected';
 notify(`Your payment of ${money(p.amt)} (${p.code}) was ${ok?'confirmed':'rejected'}.`,label(u));save();draw()}
function fixForm(u){return card(`<b>Report a repair</b><label>What is wrong?</label><input id="ft"><label>Details</label><textarea id="fd"></textarea><label>How urgent?</label><select id="fu"><option>Normal</option><option>Urgent</option></select><div style="margin-top:12px">${btn('Send request','submitFix()')}</div>`)}
function submitFix(){const u=unitOf(prof),t=$('ft').value.trim();if(!t)return toast('Say what is wrong');
 const f={id:S.fseq++,unit:u.id,by:me,title:t,desc:$('fd').value.trim(),urg:$('fu').value,status:'Open',at:Date.now(),log:['Reported by '+me]};S.fix.unshift(f);
 notify(`${f.urg} repair in ${u.id}: ${t}`,'role:Caretaker');if(f.urg==='Urgent')notify(`Urgent repair in ${u.id}: ${t}`,'Admin');save();toast('Repair request sent');draw()}
function fixList(l,act){return l.length?l.map(f=>card(`<div class="row"><b>${esc(f.title)}</b><span>${tag(f.urg)} ${tag(f.status)}</span></div><div class="sub">Unit ${f.unit} · ${esc(f.by)} · ${ago(f.at)}${f.desc?'<br>'+esc(f.desc):''}<br>${esc(f.log[f.log.length-1])}</div>${act&&f.status!=='Resolved'?`<div style="margin-top:8px">${f.status==='Open'?btn('Start work','setFix('+f.id+')'):''}${btn('Resolve','resolveFix('+f.id+')','ghost')}</div>`:''}`)).join(''):empty('No repair requests.')}
function setFix(id){const f=S.fix.find(x=>x.id===id),u=UNITS.find(x=>x.id===f.unit);f.status='In progress';f.log.push('Work started');notify(`Work has started on: ${f.title}`,label(u));save();draw()}
function resolveFix(id){const n=prompt('What was done?');if(n===null)return;const f=S.fix.find(x=>x.id===id),u=UNITS.find(x=>x.id===f.unit);f.status='Resolved';f.log.push('Resolved: '+(n||'done'));notify(`Repair resolved: ${f.title}. ${n}`,label(u));save();draw()}
function postNotice(){const t=$('nt').value.trim();if(!t)return toast('Write the notice first');S.notices.unshift({id:S.nseq++,text:t,at:Date.now()});notify('New notice: '+t,'role:Tenant');notify('New notice: '+t,'role:Caretaker');save();toast('Notice posted');draw()}
function noticesView(){return (role==='Admin'?card(`<b>Post a notice</b><label>Message to all tenants and the caretaker</label><textarea id="nt"></textarea><div style="margin-top:12px">${btn('Post notice','postNotice()')}</div>`):'')+'<h2>Notices</h2>'+(S.notices.map(n=>card(esc(n.text)+`<div class="sub">${ago(n.at)}</div>`)).join('')||empty('No notices.'))}
function unitsView(){return UNITS.map(u=>{const b=bal(u);return card(`<div class="row"><b>${esc(label(u))}</b>${tag(b>0?'Arrears':'Up to date')}</div><div class="sub">Tenant: ${esc(tenantOf(u))}<br>${mdue(u)} months due ${money(mdue(u)*u.rent)} · paid ${money(paid(u))} · balance ${money(Math.max(b,0))}</div>`)}).join('')}
function paysView(){const pend=S.pays.filter(p=>p.status==='Pending'),rest=S.pays.filter(p=>p.status!=='Pending').slice(0,8);
 return '<h2>Awaiting confirmation ('+pend.length+')</h2>'+(pend.map(p=>card(`<div class="row"><b>${money(p.amt)}</b>${tag(p.status)}</div><div class="sub">Unit ${p.unit} · M-Pesa ${esc(p.code)} · ${ago(p.at)}</div><div style="margin-top:8px">${btn('Confirm','confirmPay('+p.id+',true)')}${btn('Reject','confirmPay('+p.id+',false)','ghost')}</div>`)).join('')||empty('Nothing to confirm.'))+'<h2>Recent payments</h2>'+rest.map(payCard).join('')}
function overview(){const due=UNITS.reduce((a,u)=>a+mdue(u)*u.rent,0),col=UNITS.reduce((a,u)=>a+paid(u),0),arr=UNITS.reduce((a,u)=>a+Math.max(bal(u),0),0),occ=UNITS.filter(u=>tenantOf(u)!=='Vacant').length;
 return `<div class="grid four">${stat(money(col),'collected','ok')}${stat(money(arr),'in arrears','bad')}${stat(occ+'/'+UNITS.length,'units with a tenant')}${stat(S.fix.filter(f=>f.status!=='Resolved').length,'open repairs','warn')}</div>
 <div class="card"><b>Collection rate</b><div class="sub">${due?Math.round(col/due*100):0}% of rent due has been collected. ${S.pays.filter(p=>p.status==='Pending').length} payment(s) await confirmation.</div></div>
 <div class="card"><b>Arrears by unit (KES thousands)</b>${bars(UNITS.map(u=>[u.id+' '+u.prop.split(' ')[0],Math.round(Math.max(bal(u),0)/1000)]))}</div>`}
function view(){
 if(tab==='notices')return noticesView();
 if(role==='Tenant'){const u=unitOf(prof);if(!u)return empty('No unit is linked to your account.');
  if(tab==='fix')return fixForm(u)+'<h2>My repair requests</h2>'+fixList(S.fix.filter(f=>f.unit===u.id),0);
  const b=bal(u);
  return card(`<b>${esc(label(u))}</b><div class="sub">Rent due so far: ${money(mdue(u)*u.rent)} (${mdue(u)} months) · Paid: ${money(paid(u))}</div><div style="margin-top:6px">Balance: <b class="${b>0?'bad':'ok'}">${money(Math.max(b,0))}</b>${b<0?' (credit '+money(-b)+')':''}</div>`)+
  card(`<b>Record a payment</b><div class="sub">Pay by M-Pesa as usual, then record the amount and the M-Pesa code here so the landlord can confirm it.</div><label>Amount (KES)</label><input id="pa" type="number" min="1"><label>M-Pesa code</label><input id="pc" maxlength="10" placeholder="e.g. SJK2A8B3QX"><div style="margin-top:12px">${btn('Submit payment','submitPay()')}</div>`)+
  '<h2>My payments</h2>'+(S.pays.filter(p=>p.unit===u.id).map(payCard).join('')||empty('No payments yet.'))}
 if(role==='Caretaker')return '<h2>Repairs</h2>'+fixList(S.fix,1);
 if(tab==='units')return unitsView();if(tab==='pays')return paysView();if(tab==='fix')return '<h2>Repairs</h2>'+fixList(S.fix,1);
 return overview()}

let S;try{S=JSON.parse(localStorage.getItem(KEY+'_d'))}catch(e){}
if(!S)S=seed();
const save=()=>{try{localStorage.setItem(KEY+'_d',JSON.stringify(S))}catch(e){}};
let tab='home',role='',me='',prof='',mode='login',aerr='';
const key=()=>role==='Admin'?'Admin':(role===PROFROLE&&prof?prof:me);
const notify=(m,who)=>{S.notes.unshift({m,who,at:Date.now(),read:false})};
const mine=()=>S.notes.filter(n=>n.who===key()||n.who==='role:'+role);
const getU=()=>{try{return JSON.parse(localStorage.getItem(KEY+'_users'))||[]}catch(e){return[]}};
const putU=u=>{try{localStorage.setItem(KEY+'_users',JSON.stringify(u))}catch(e){}};
const cur=()=>{try{const e=localStorage.getItem(KEY+'_sess');return getU().find(u=>u.email===e)||null}catch(e){return null}};
async function hash(p,s){const enc=new TextEncoder(),k=await crypto.subtle.importKey('raw',enc.encode(p),'PBKDF2',false,['deriveBits']);
 const b=await crypto.subtle.deriveBits({name:'PBKDF2',salt:enc.encode(s),iterations:100000,hash:'SHA-256'},k,256);
 return Array.from(new Uint8Array(b)).map(x=>x.toString(16).padStart(2,'0')).join('')}
const bad=m=>{aerr=m;const e=$('xerr');if(e)e.textContent=m};
const xrole=()=>{if(PROFROLE)$('xpf').style.display=$('xr').value===PROFROLE?'block':'none'};
function authView(){const reg=mode==='reg';
 return `<div class="card auth"><b>${reg?'Create your account':'Log in'}</b>
 ${reg?`<label>Full name</label><input id="xn" autocomplete="name">`:''}
 <label>Email</label><input id="xe" type="email" autocomplete="email">
 <label>Password</label><input id="xp" type="password" autocomplete="${reg?'new-password':'current-password'}">
 ${reg?`<label>Confirm password</label><input id="xp2" type="password" autocomplete="new-password">
 <label>Account type</label><select id="xr" onchange="xrole()">${ROLES.map(r=>`<option>${r}</option>`).join('')}</select>
 ${PROFROLE?`<div id="xpf" style="display:${ROLES[0]===PROFROLE?'block':'none'}"><label>${PROFLABEL}</label><select id="xl">${PROF.map(p=>`<option>${esc(p)}</option>`).join('')}</select></div>`:''}
 <div class="sub" style="margin-top:8px">The first account created becomes the administrator.</div>`:''}
 <div class="err" id="xerr">${esc(aerr)}</div>
 <div style="margin-top:12px"><button class="btn" onclick="${reg?'doReg()':'doLogin()'}">${reg?'Register':'Log in'}</button></div>
 <div class="sub" style="margin-top:12px">${reg?'Already registered?':'New here?'} <button class="link" onclick="mode='${reg?'login':'reg'}';aerr='';draw()">${reg?'Log in':'Create an account'}</button></div></div>`}
async function doReg(){const n=$('xn').value.trim(),e=$('xe').value.trim().toLowerCase(),p=$('xp').value;
 if(!n)return bad('Enter your full name.');
 if(!/^\S+@\S+\.\S+$/.test(e))return bad('Enter a valid email address.');
 if(p.length<8)return bad('Password must be at least 8 characters.');
 if(p!==$('xp2').value)return bad('Passwords do not match.');
 const us=getU();if(us.some(u=>u.email===e))return bad('That email is already registered. Log in instead.');
 const salt=Array.from(crypto.getRandomValues(new Uint8Array(8))).join('-');
 const r=us.length?$('xr').value:'Admin',pf=(r===PROFROLE)?$('xl').value:'';
 us.push({email:e,name:n,role:r,prof:pf,salt,h:await hash(p,salt)});putU(us);
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
async function doLogin(){const e=$('xe').value.trim().toLowerCase(),u=getU().find(x=>x.email===e);
 if(!u||u.h!==await hash($('xp').value,u.salt))return bad('Email or password is incorrect.');
 try{localStorage.setItem(KEY+'_sess',e)}catch(x){}
 start()}
function start(){const u=cur();if(!u)return;role=u.role;me=u.name;prof=u.prof||'';tab='home';aerr='';draw()}
function logout(){try{localStorage.removeItem(KEY+'_sess')}catch(e){}mode='login';aerr='';draw()}
function drawNav(){const u=mine().filter(n=>!n.read).length;
 $('nav').innerHTML=tabs().map(([k,l])=>`<button class="${tab===k?'on':''}" onclick="go('${k}')">${l}${k==='alerts'&&u?`<span class="dot">${u}</span>`:''}</button>`).join('')}
const go=k=>{tab=k;draw()};
function alertsView(){const n=mine();n.forEach(x=>x.read=true);save();return n.length?n.map(x=>card(esc(x.m)+`<div class="sub">${ago(x.at)}</div>`)).join(''):empty('No alerts yet.')}
function draw(){const u=cur();$('who').innerHTML=u?`<span>${esc(u.name)} · ${role}</span><button class="btn sm ghost" onclick="logout()">Log out</button>`:'';
 if(!u){$('nav').innerHTML='';$('main').innerHTML=authView();return}
 drawNav();$('main').innerHTML=tab==='alerts'?alertsView():view()}
start();draw();
